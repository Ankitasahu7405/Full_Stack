<?php

?>
@include('website.layout.header')
@yield('main_container')
@include('website.layout.footer')