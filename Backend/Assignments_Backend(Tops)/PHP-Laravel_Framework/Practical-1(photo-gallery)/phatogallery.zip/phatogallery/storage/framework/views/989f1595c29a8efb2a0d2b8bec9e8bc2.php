
<div class="container d-flex justify-content-center">
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card p-3 py-4">
        <div class="text-center"> 
		<img src="<?php echo e(url('website/upload/'.$d->file)); ?>"  width="100" class="rounded-circle">
            <h3 class="mt-2"><?php echo e($d->name); ?></h3>
			<span class="mt-1 clearfix"><?php echo e($d->description); ?></span>
			

			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			
			<hr class="line">
			
			<small class="mt-4">I am an web developer working at google Inc at california,USA</small>
              <div class="social-buttons mt-5"> 
			   <button class="neo-button"><i class="fa fa-facebook fa-1x"></i> </button> 
			   <button class="neo-button"><i class="fa fa-linkedin fa-1x"></i></button> 
			   <button class="neo-button"><i class="fa fa-google fa-1x"></i> </button> 
			   <button class="neo-button"><i class="fa fa-youtube fa-1x"></i> </button>
			   <button class="neo-button"><i class="fa fa-twitter fa-1x"></i> </button>
			  </div>
			  
			 <div class="profile mt-5">
			 
			 <button class="profile_button px-5">View profile</button>

		</div>
			   
        </div>
    </div>
</div>


<?php /**PATH E:\xamp\htdocs\Laravel\phatogallery\resources\views/website/imageview.blade.php ENDPATH**/ ?>