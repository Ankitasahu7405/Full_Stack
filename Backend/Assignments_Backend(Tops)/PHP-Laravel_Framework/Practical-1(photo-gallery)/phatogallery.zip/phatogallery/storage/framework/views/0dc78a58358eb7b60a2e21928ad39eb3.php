

<?php $__env->startSection('main_container'); ?>
<form action="<?php echo e(url('/imageupload')); ?>" method="post" enctype="multipart/form-data">
<h1 class="text-center">PHATO UPLOAD </H1>
        <div class="container">
        <div class="row">
            <div class="container my-25">
                <a href="<?php echo e(url('/imageview')); ?>" class="btn btn-primary">view gallery</a>
</div>

</div>
<div class="container col-md-6 my-4">

        <div class="form-groups">
		<?php echo csrf_field(); ?>
		
                <label>Name</label>
                <input type="text" name="name" class="form-control" placeholder="enter your name">
            </div><br>
			
			<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger"><?php echo e($meassage); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <div class="form-groups">
                <label>File</label>
                <input type="file" name="file" class="form-control" placeholder="enter your file">
            </div><br>
            <div class="form-groups">
                <label>Description</label>
                <textarea name="description" cols="20" rows="10" class="form-control"></textarea>
				
    </div><br>
	<button type="submit" name="submit" class="btn btn-primary">Save</button>
  </div>


</form>
</body>
</html>
<div>
<?php $__env->stopSection(); ?>
</div>
<?php echo $__env->make('website.layout.structure', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xamp\htdocs\Laravel\phatogallery\resources\views/website/imageupload.blade.php ENDPATH**/ ?>